"""
Scraper produtor-consumidor: extração de listagem (produtores)
e enriquecimento de detalhes (consumidores) com deduplicação
e retry integrados.
"""

import os
import re
import csv
import time
import random
import logging
import threading
import queue
from typing import Dict, Optional, Set

import pandas as pd
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from scraper_rio.config import (
    MAP_IMOVEL, MAP_CONDOMINIO, CSV_FIELDNAMES,
    RESTART_DRIVER_EVERY, CONSUMER_QUEUE_TIMEOUT,
)
from scraper_rio.driver import start_driver, scroll_inteligente, safe_restart_driver
from scraper_rio.utils import (
    extract_number, extract_decimal_number, safe_get_text,
    safe_get_attribute, parse_pt_date_to_iso, geocode_fallback_nominatim, retry,
)

logger = logging.getLogger(__name__)

# ══════════════════════════════════════════════════════════════════════════════
#  ESTADO COMPARTILHADO (Thread-Safe)
# ══════════════════════════════════════════════════════════════════════════════

LINK_QUEUE: queue.Queue = queue.Queue()
PRODUCERS_DONE = threading.Event()

# Deduplicação de URLs na fila
_SEEN_URLS: Set[str] = set()
_SEEN_LOCK = threading.Lock()


def reset_shared_state():
    """Reseta o estado global entre execuções (útil para testes)."""
    global _SEEN_URLS
    LINK_QUEUE.queue.clear()
    PRODUCERS_DONE.clear()
    with _SEEN_LOCK:
        _SEEN_URLS = set()


# ══════════════════════════════════════════════════════════════════════════════
#  PARSING DE CARD (LISTAGEM)
# ══════════════════════════════════════════════════════════════════════════════

def parse_card_resumo(card_element: WebElement) -> Optional[Dict]:
    """
    Extrai dados básicos de um card de listagem.
    Retorna dict com dados parciais ou None se inválido.
    """
    try:
        data = {}
        data['url'] = safe_get_attribute(card_element, 'a', 'href', '')
        if not data['url']:
            return None

        price_txt = safe_get_text(
            card_element, 'div[data-cy="rp-cardProperty-price-txt"] p.text-2-25'
        )
        data['valor_R$'] = extract_number(price_txt)
        data['area_m2'] = extract_number(
            safe_get_text(card_element, 'li[data-cy="rp-cardProperty-propertyArea-txt"] h3')
        )
        data['quartos'] = extract_number(
            safe_get_text(card_element, 'li[data-cy="rp-cardProperty-bedroomQuantity-txt"] h3')
        )
        data['vagas'] = extract_number(
            safe_get_text(card_element, 'li[data-cy="rp-cardProperty-parkingSpacesQuantity-txt"] h3')
        )
        data['banheiros'] = extract_number(
            safe_get_text(card_element, 'li[data-cy="rp-cardProperty-bathroomQuantity-txt"] h3')
        )

        loc_text = safe_get_text(card_element, 'h2[data-cy="rp-cardProperty-location-txt"]')
        if " em " in loc_text:
            data['tipo'], _, resto = loc_text.partition(' em ')
            bairro, _, cidade = resto.partition(',')
            data['bairro'] = bairro.strip()
            data['cidade'] = cidade.strip()
        else:
            data['tipo'] = "Indefinido"
            data['bairro'] = loc_text
            data['cidade'] = "Rio de Janeiro"

        data['rua'] = safe_get_text(
            card_element, 'p[data-cy="rp-cardProperty-street-txt"]', 'Rua Não Informada'
        )

        costs_text = safe_get_text(
            card_element, 'div[data-cy="rp-cardProperty-price-txt"] p.text-1-75'
        )
        data['condominio_R$'] = 0.0
        data['iptu_R$'] = 0.0
        if costs_text:
            cond_match = re.search(r'Cond\.\s*(R\$\s*[\d\.,]+)', costs_text, re.IGNORECASE)
            if cond_match:
                data['condominio_R$'] = extract_decimal_number(cond_match.group(1))
            iptu_match = re.search(r'IPTU\s*(R\$\s*[\d\.,]+)', costs_text, re.IGNORECASE)
            if iptu_match:
                data['iptu_R$'] = extract_decimal_number(iptu_match.group(1))

        data['destaque'] = safe_get_text(
            card_element, 'li[data-cy="rp-cardProperty-tag-txt"]', 'Sem Destaque'
        )
        data['imagem_url'] = safe_get_attribute(
            card_element, 'img', 'src', 'Imagem Não Encontrada'
        )

        return data
    except Exception:
        return None


def _enqueue_with_dedup(data: Dict) -> bool:
    """Adiciona à fila somente se a URL ainda não foi vista. Retorna True se enfileirou."""
    url = data.get('url', '')
    if not url:
        return False
    with _SEEN_LOCK:
        if url in _SEEN_URLS:
            return False
        _SEEN_URLS.add(url)
    LINK_QUEUE.put(data)
    return True


# ══════════════════════════════════════════════════════════════════════════════
#  PRODUTOR — VARREDURA DE LISTAGEM
# ══════════════════════════════════════════════════════════════════════════════

def produtor_listagem(tarefa: Dict):
    """
    Varre páginas de listagem e envia cards para a fila.
    Cada tarefa contém zona, range de páginas e worker_id.
    """
    label = f"{tarefa['zona']['nome']} [{tarefa['worker_id']}]"
    slug = tarefa['zona']['slug']
    paginas = tarefa['paginas']

    logger.info(f"PRODUTOR INICIADO: {label}")
    driver = None
    total_enqueued = 0
    consecutive_empty = 0

    try:
        time.sleep(random.uniform(1, 4))
        driver = start_driver()
        base_url = f"https://www.zapimoveis.com.br/venda/imoveis/{slug}/"

        for pagina in paginas:
            try:
                driver.get(f"{base_url}?pagina={pagina}")

                # Cloudflare check
                if "Checking your browser" in driver.title:
                    logger.warning(f"[{label}] Cloudflare check na pág {pagina}. Aguardando 10s...")
                    time.sleep(10)

                scroll_inteligente(driver)

                card_elements = driver.find_elements(
                    By.CSS_SELECTOR, 'li[data-cy="rp-property-cd"]'
                )

                # Retry de scroll se poucos cards
                if len(card_elements) < 5:
                    scroll_inteligente(driver)
                    card_elements = driver.find_elements(
                        By.CSS_SELECTOR, 'li[data-cy="rp-property-cd"]'
                    )

                count_pag = 0
                for el in card_elements:
                    resumo = parse_card_resumo(el)
                    if resumo and _enqueue_with_dedup(resumo):
                        count_pag += 1

                total_enqueued += count_pag
                logger.info(f"[{label}] Pág {pagina}: {count_pag} novos links (total: {total_enqueued})")

                # Detecção de fim real: se 5 páginas seguidas sem resultados, para
                if count_pag == 0:
                    consecutive_empty += 1
                    if consecutive_empty >= 5:
                        logger.info(f"[{label}] 5 páginas vazias seguidas. Encerrando zona.")
                        break
                else:
                    consecutive_empty = 0

            except Exception as e:
                logger.error(f"[{label}] Erro pág {pagina}: {e}")

    except Exception as e:
        logger.error(f"[{label}] Erro fatal: {e}")
    finally:
        if driver:
            try:
                driver.quit()
            except Exception:
                pass
    logger.info(f"PRODUTOR FINALIZADO: {label} — {total_enqueued} links enfileirados")


# ══════════════════════════════════════════════════════════════════════════════
#  CONSUMIDOR — DETALHES COM SAVE-AS-YOU-GO
# ══════════════════════════════════════════════════════════════════════════════

def _enriquecer_detalhes(driver, card_data: Dict) -> bool:
    """
    Acessa a página de detalhes e enriquece o dict in-place.
    Retorna True se teve sucesso, False se falhou.
    """
    url = card_data.get('url')
    if not url:
        return False

    try:
        driver.get(url)
        if "Checking your browser" in driver.title:
            time.sleep(5)
        time.sleep(1.5)

        # --- DADOS BÁSICOS ---
        card_data['descricao'] = safe_get_text(driver, "p[data-testid='description-content']")

        end_raw = safe_get_text(driver, "p[data-testid='address-info-value']")
        if not end_raw:
            end_raw = safe_get_text(driver, "p[data-testid='location-address']")

        card_data['endereco_completo'] = end_raw
        card_data['numero'] = extract_number(end_raw)
        card_data['corretora'] = safe_get_text(driver, "a[data-testid='official-store-redirect-link']")

        card_data['suites'] = extract_number(safe_get_text(driver, "li[itemprop='numberOfSuites']"))
        card_data['quartos'] = extract_number(safe_get_text(driver, "li[itemprop='numberOfRooms']"))
        card_data['andar'] = extract_number(safe_get_text(driver, "li[itemprop='floorLevel']"))

        # --- FEATURES POR PAINEL ---
        _processar_aba(driver, card_data, "panel-unitAmenities", MAP_IMOVEL)

        try:
            tab_condo = driver.find_element(By.ID, "sectionAmenities")
            if "olx-tabs__tab--active" not in tab_condo.get_attribute("class"):
                driver.execute_script(
                    "arguments[0].scrollIntoView({block: 'center', inline: 'nearest'});",
                    tab_condo
                )
                time.sleep(0.3)
                driver.execute_script("arguments[0].click();", tab_condo)
                time.sleep(1.0)
            _processar_aba(driver, card_data, "panel-sectionAmenities", MAP_CONDOMINIO)
        except Exception:
            for k in MAP_CONDOMINIO:
                card_data[k] = False

        # --- AVALIAÇÃO ---
        rating_raw = safe_get_text(driver, '[data-testid="rating-container"] .rating-container__text')
        m = re.search(r"(\d+(?:\.\d+)?)\/\d+\s*\((\d+)", rating_raw)
        card_data['nota_media'] = float(m.group(1)) if m else 0.0
        card_data['total_avaliacoes'] = int(m.group(2)) if m else 0

        # --- DATA DO ANÚNCIO ---
        date_raw = safe_get_text(driver, '[data-testid="listing-created-date"]')
        if date_raw:
            created_part = date_raw.split(",")[0].replace("Anúncio criado em", "").strip()
            card_data['anuncio_criado'] = parse_pt_date_to_iso(created_part)
        else:
            card_data['anuncio_criado'] = pd.Timestamp.now().strftime('%Y-%m-%d')

        # --- COORDENADAS (com fallback Nominatim) ---
        _extrair_coordenadas(driver, card_data)

        return True

    except Exception as e:
        logger.warning(f"Erro ao enriquecer {url}: {e}")
        card_data['_enrich_error'] = str(e)
        return False


def _processar_aba(driver, card_data: Dict, painel_id: str, feature_map: Dict):
    """Extrai features de um painel específico (imóvel ou condomínio)."""
    try:
        painel = driver.find_element(By.ID, painel_id)
        try:
            btn = painel.find_element(By.CSS_SELECTOR, "button[data-cy='ldp-TextCollapse-btn']")
            if btn.is_displayed():
                driver.execute_script("arguments[0].click();", btn)
                time.sleep(0.5)
        except Exception:
            pass

        for key, selector in feature_map.items():
            try:
                painel.find_element(By.CSS_SELECTOR, selector)
                card_data[key] = True
            except Exception:
                card_data[key] = False
    except Exception:
        for key in feature_map:
            card_data[key] = False


def _extrair_coordenadas(driver, card_data: Dict):
    """Extrai coordenadas do mapa ou faz fallback via Nominatim."""
    lat_val, lon_val = 0.0, 0.0
    origem_geo = "Nao Encontrado"

    # Tentativa 1: iframe do mapa
    try:
        iframe = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "iframe[data-testid='map-iframe']"))
        )
        src_url = iframe.get_attribute("src") or ""
        match = re.search(r'(-?\d{1,2}\.\d+)[,\s]+(-?\d{1,3}\.\d+)', src_url)
        if match:
            lat_val = float(match.group(1))
            lon_val = float(match.group(2))
            origem_geo = "Site ZAP"
    except Exception:
        pass

    # Tentativa 2: Nominatim (com rate limiting)
    if lat_val == 0.0 and card_data.get('endereco_completo'):
        lat_val, lon_val = geocode_fallback_nominatim(card_data['endereco_completo'])
        if lat_val != 0.0:
            origem_geo = "API Nominatim"

    card_data['latitude'] = lat_val
    card_data['longitude'] = lon_val
    card_data['origem_geo'] = origem_geo
    card_data['coordenadas'] = f"{lat_val},{lon_val}" if lat_val != 0.0 else "Url encontrada sem coordenadas"


def consumidor_detalhes(worker_id: int, headless: bool = False):
    """
    Worker consumidor: lê da fila, visita páginas de detalhe,
    e salva CSV incrementalmente.
    """
    logger.info(f"CONSUMIDOR #{worker_id} PRONTO.")
    driver = None
    processed_count = 0
    error_count = 0
    filename_temp = f"temp_worker_{worker_id}.csv"

    file_exists = os.path.isfile(filename_temp)
    csv_file = open(filename_temp, 'a', newline='', encoding='utf-8-sig', buffering=1)

    writer = csv.DictWriter(
        csv_file, fieldnames=CSV_FIELDNAMES, delimiter=';', extrasaction='ignore'
    )
    if not file_exists:
        writer.writeheader()
        csv_file.flush()

    try:
        time.sleep(random.uniform(1, 5))
        driver = start_driver(headless=headless)

        while True:
            # --- Leitura da fila com encerramento inteligente ---
            try:
                item = LINK_QUEUE.get(timeout=CONSUMER_QUEUE_TIMEOUT)
            except queue.Empty:
                if PRODUCERS_DONE.is_set() and LINK_QUEUE.empty():
                    logger.info(f"Consumidor #{worker_id}: fila vazia e produtores finalizados. Encerrando.")
                    break
                continue

            # Sentinela de encerramento
            if item is None:
                break

            # --- Processamento com retry ---
            success = False
            for attempt in range(3):
                try:
                    success = _enriquecer_detalhes(driver, item)
                    break
                except Exception as e:
                    logger.warning(f"Consumidor #{worker_id}: tentativa {attempt + 1}/3 falhou: {e}")
                    if attempt < 2:
                        driver = safe_restart_driver(driver, headless=headless)

            if success:
                writer.writerow(item)
                csv_file.flush()
            else:
                error_count += 1
                # Salva mesmo com erro parcial (melhor ter dados parciais do que nada)
                writer.writerow(item)
                csv_file.flush()

            LINK_QUEUE.task_done()
            processed_count += 1

            # Restart periódico para liberar memória
            if processed_count % RESTART_DRIVER_EVERY == 0:
                driver = safe_restart_driver(driver, headless=headless)

    except Exception as e:
        logger.error(f"Consumidor #{worker_id} falhou: {e}")
    finally:
        csv_file.close()
        if driver:
            try:
                driver.quit()
            except Exception:
                pass
        logger.info(
            f"Consumidor #{worker_id} encerrou. "
            f"{processed_count} processados ({error_count} com erro parcial) em {filename_temp}."
        )
