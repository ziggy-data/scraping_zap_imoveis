"""
Módulos de enriquecimento pós-scraping:
- geo: contexto geográfico vetorizado
- finance: análise financeira com parâmetros da Caixa
- nlp: mineração de texto (tags e urgência)
- quality: limpeza, dedup, segmentação
"""

from scraper_rio.enrichment.geo import enriquecer_geo_contexto_vetorizado
from scraper_rio.enrichment.finance import analise_financeira
from scraper_rio.enrichment.nlp import extrair_tags_avancadas, detectar_urgencia_venda
from scraper_rio.enrichment.quality import (
    aplicar_regras_qualidade,
    calcular_media_inteligente,
    analisar_saturacao_rua,
    segmentar_mercado_dinamico,
    calcular_dias_mercado,
    calcular_indice_conforto,
)

__all__ = [
    'enriquecer_geo_contexto_vetorizado',
    'analise_financeira',
    'extrair_tags_avancadas',
    'detectar_urgencia_venda',
    'aplicar_regras_qualidade',
    'calcular_media_inteligente',
    'analisar_saturacao_rua',
    'segmentar_mercado_dinamico',
    'calcular_dias_mercado',
    'calcular_indice_conforto',
]
