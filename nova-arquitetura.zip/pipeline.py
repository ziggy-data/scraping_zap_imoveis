"""
Pipeline de pós-processamento:
Unifica CSVs temporários, executa enriquecimento em ordem,
otimiza para Power BI e salva dataset final.
"""

import os
import glob
import logging

import pandas as pd

from scraper_rio.enrichment import (
    aplicar_regras_qualidade,
    calcular_media_inteligente,
    enriquecer_geo_contexto_vetorizado,
    analise_financeira,
    analisar_saturacao_rua,
    segmentar_mercado_dinamico,
    calcular_dias_mercado,
    detectar_urgencia_venda,
    extrair_tags_avancadas,
    calcular_indice_conforto,
)

logger = logging.getLogger(__name__)


def unificar_e_tratar(output_filename: str = "DATASET_RIO_BI_READY.csv"):
    """
    Pipeline principal:
    1. Unifica CSVs temporários dos workers
    2. Executa pipeline de enriquecimento em ordem
    3. Otimiza tipos para Power BI
    4. Salva arquivo final
    """
    logger.info("=== UNIFICANDO E PROCESSANDO DADOS ===")

    all_files = glob.glob("temp_worker_*.csv")
    if not all_files:
        logger.error("Nenhum arquivo temporário encontrado!")
        return None

    try:
        # ── FASE 1: Carga e Unificação ──
        df_list = []
        for f in all_files:
            try:
                chunk = pd.read_csv(f, sep=";", dtype=str)  # Tudo como string inicialmente
                df_list.append(chunk)
                logger.info(f"  Carregado: {f} ({len(chunk)} registros)")
            except Exception as e:
                logger.warning(f"  Erro ao ler {f}: {e}")

        if not df_list:
            logger.error("Nenhum dado carregado!")
            return None

        df = pd.concat(df_list, ignore_index=True)
        logger.info(f"Total bruto: {len(df)} registros")

        # ── FASE 2: Pipeline de Enriquecimento (ORDEM IMPORTA) ──

        # 1. Limpeza e dedup (primeiro — reduz volume)
        df = aplicar_regras_qualidade(df)

        # 2. Médias inteligentes de preço (precisa de dados limpos)
        df = calcular_media_inteligente(df, min_amostras_rua=3)

        # 3. Geo-contexto vetorizado (precisa de coordenadas)
        df = enriquecer_geo_contexto_vetorizado(df)

        # 4. Análise financeira (precisa de diferença_percentual do step 2 e dist_transporte do step 3)
        df = analise_financeira(df)

        # 5. Saturação de rua
        df = analisar_saturacao_rua(df)

        # 6. Segmentação dinâmica
        df = segmentar_mercado_dinamico(df)

        # 7. Dias no mercado (precisa ser antes de urgência)
        df = calcular_dias_mercado(df)

        # 8. NLP: tags de texto
        df = extrair_tags_avancadas(df)

        # 9. Urgência (precisa de dias_no_mercado)
        df = detectar_urgencia_venda(df)

        # 10. Índice de conforto (precisa de tags NLP e geo)
        df = calcular_indice_conforto(df)

        # ── FASE 3: Otimização para Power BI ──
        df = _otimizar_para_powerbi(df)

        # ── FASE 4: Fusão de colunas redundantes ──
        df = _fundir_colunas(df)

        # ── FASE 5: Salvar ──
        df.to_csv(output_filename, sep=";", decimal=",", index=False, encoding="utf-8-sig")
        logger.info(f"SUCESSO! Dataset BI gerado: {output_filename}")
        logger.info(f"Total Imóveis: {len(df)} | Colunas: {len(df.columns)}")

        # Limpa temporários
        for f in all_files:
            try:
                os.remove(f)
            except Exception:
                pass

        return df

    except Exception as e:
        logger.error(f"Erro no pipeline: {e}", exc_info=True)
        return None


def _otimizar_para_powerbi(df: pd.DataFrame) -> pd.DataFrame:
    """Ajusta tipos de dados para compatibilidade com Power BI."""
    logger.info("Otimizando tipos de dados para Power BI...")

    # Nulos em colunas financeiras → 0
    cols_financeiras = [
        'condominio_R$', 'iptu_R$', 'valor_R$', 'area_m2', 'custo_fixo_mensal',
        'entrada_minima', 'valor_financiado', 'primeira_parcela_estimada', 'renda_minima_familiar',
    ]
    for col in cols_financeiras:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)

    # Booleanos → int (0/1)
    bool_prefixes = ('tem_', 'aceita_', 'tag_', 'flag_', 'bool_')
    for col in df.columns:
        if df[col].dtype == 'bool' or any(col.startswith(p) for p in bool_prefixes):
            try:
                df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0).astype(int)
            except Exception:
                pass

    # Data no formato ISO
    if 'anuncio_criado' in df.columns:
        df['anuncio_criado'] = pd.to_datetime(df['anuncio_criado'], errors='coerce').dt.strftime('%Y-%m-%d')

    return df


def _fundir_colunas(df: pd.DataFrame) -> pd.DataFrame:
    """Cria colunas definitivas por fusão OR de fontes redundantes."""
    logger.info("Fundindo colunas redundantes (Lógica OR)...")

    # Vista Mar definitiva (site + NLP)
    _fuse_or(df, ['tem_vista_pro_mar', 'tag_vista_mar'], 'final_tem_vista_mar')

    # Varanda definitiva
    _fuse_or(df, ['tem_varanda', 'tem_varanda_gourmet'], 'final_tem_varanda')

    # Lazer relevante (flag rápida)
    _fuse_or(df, ['tem_piscina', 'tem_churrasqueira', 'tem_academia'], 'final_tem_lazer')

    return df


def _fuse_or(df: pd.DataFrame, source_cols: list, target_col: str):
    """Fusão OR de múltiplas colunas booleanas."""
    existing = [c for c in source_cols if c in df.columns]
    if existing:
        df[target_col] = df[existing].max(axis=1).fillna(0).astype(int)
