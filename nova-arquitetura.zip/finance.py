"""
Análise financeira com parâmetros diferenciados
(MCMV vs mercado livre) e cálculos vetorizados.
"""

import logging

import numpy as np
import pandas as pd

from scraper_rio.config import PARAMS_FINANCEIROS

logger = logging.getLogger(__name__)


def analise_financeira(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calcula métricas financeiras vetorizadas:
    - Custo de aquisição (ITBI + cartório)
    - Simulação de financiamento SAC (com juros diferenciados por faixa)
    - Custo fixo mensal (condomínio + IPTU)
    - Estimativa de aluguel e fluxo de caixa
    - Payback e score de investimento
    """
    logger.info("Executando Análise Financeira (Parâmetros Caixa)...")
    p = PARAMS_FINANCEIROS

    valor = df['valor_R$'].values.astype(float)
    cond = df['condominio_R$'].values.astype(float)
    iptu = df['iptu_R$'].values.astype(float)

    # ── 1. Custo Total de Aquisição ──
    custo_aquisicao = valor * (1 + p.taxa_itbi + p.taxa_cartorio)
    df['custo_aquisicao_total'] = np.round(custo_aquisicao, 2)

    # ── 2. Entrada mínima e valor financiado ──
    entrada = valor * (1 - p.percentual_financiavel)
    financiado = valor * p.percentual_financiavel
    df['entrada_minima'] = np.round(entrada, 2)
    df['valor_financiado'] = np.round(financiado, 2)

    # ── 3. Primeira parcela SAC (juros diferenciados por faixa) ──
    # Vetorizado: imóveis até teto_mcmv usam juros menores
    is_mcmv = valor <= p.teto_mcmv
    juros_aa = np.where(is_mcmv, p.juros_aa_mcmv_f3, p.juros_aa_mercado)
    juros_mensal = (1 + juros_aa) ** (1/12) - 1

    amortizacao = financiado / p.prazo_meses
    juros_primeira = financiado * juros_mensal
    primeira_parcela = amortizacao + juros_primeira

    df['primeira_parcela_estimada'] = np.round(primeira_parcela, 2)
    df['faixa_financiamento'] = np.where(is_mcmv, 'MCMV', 'Mercado Livre')
    df['juros_aa_aplicado'] = np.round(juros_aa * 100, 2)  # Em percentual

    # ── 4. Renda mínima (parcela ≤ 30% da renda) ──
    df['renda_minima_familiar'] = np.round(primeira_parcela / 0.30, 2)

    # ── 5. Custo fixo mensal ──
    custo_fixo = cond + (iptu / 12)
    df['custo_fixo_mensal'] = np.round(custo_fixo, 2)

    # ── 6. Estimativa de aluguel e fluxo de caixa ──
    aluguel_est = valor * p.yield_aluguel
    fluxo_caixa = aluguel_est - custo_fixo

    df['aluguel_estimado'] = np.round(aluguel_est, 2)
    df['fluxo_caixa_mensal'] = np.round(fluxo_caixa, 2)

    # ── 7. Payback simples (anos) ──
    with np.errstate(divide='ignore', invalid='ignore'):
        payback = np.where(
            fluxo_caixa > 0,
            custo_aquisicao / (fluxo_caixa * 12),
            999.0
        )
    df['anos_payback'] = np.round(payback, 1)

    # ── 8. Score de investimento (0-10) — vetorizado ──
    score = np.full(len(df), 5.0)

    # Desconto sobre referência
    dif_pct = pd.to_numeric(df.get('diferenca_percentual', 0), errors='coerce').fillna(0).values
    score += np.where(dif_pct < -15, 2, np.where(dif_pct > 15, -2, 0))

    # Transporte próximo
    dist_t = pd.to_numeric(df.get('dist_transporte_km', 99), errors='coerce').fillna(99).values
    score += np.where(dist_t < 0.8, 1, 0)

    # Custo fixo baixo
    score += np.where(custo_fixo < 1000, 1, np.where(custo_fixo > 2500, -1, 0))

    # Payback rápido (bônus)
    score += np.where(payback < 15, 1, np.where(payback > 30, -1, 0))

    # MCMV é mais acessível (bônus para investidor)
    score += np.where(is_mcmv, 0.5, 0)

    df['score_investimento'] = np.clip(np.round(score, 0).astype(int), 0, 10)

    logger.info("Análise financeira concluída.")
    return df
