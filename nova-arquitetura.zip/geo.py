"""
Enriquecimento geográfico vetorizado.
Calcula distâncias de todos os imóveis para todos os POIs
usando NumPy em vez de apply(axis=1).
"""

import logging
from typing import Dict, Tuple

import numpy as np
import pandas as pd

from scraper_rio.config import POIS_RIO, BAIRROS_TURISTICOS
from scraper_rio.utils import haversine_vectorized

logger = logging.getLogger(__name__)


def _parse_coordenadas(df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Parseia a coluna 'coordenadas' e retorna arrays de lat, lon, e máscara de válidos.
    """
    lats = np.zeros(len(df))
    lons = np.zeros(len(df))
    valid = np.zeros(len(df), dtype=bool)

    for i, coord in enumerate(df['coordenadas'].values):
        if pd.isna(coord) or ',' not in str(coord):
            continue
        try:
            parts = str(coord).split(',')
            lat = float(parts[0])
            lon = float(parts[1])
            if lat != 0.0 and lon != 0.0:
                lats[i] = lat
                lons[i] = lon
                valid[i] = True
        except (ValueError, IndexError):
            continue

    return lats, lons, valid


def _encontrar_mais_proximo_vetorizado(
    lats: np.ndarray, lons: np.ndarray, valid: np.ndarray,
    pois: Dict[str, Tuple[float, float]]
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Para cada imóvel, encontra o POI mais próximo de uma categoria.
    Retorna (array de distâncias, array de nomes).
    Totalmente vetorizado — sem loops por imóvel.
    """
    n = len(lats)
    min_dists = np.full(n, 999.9)
    min_names = np.full(n, "N/A", dtype=object)

    for nome, (plat, plon) in pois.items():
        dists = haversine_vectorized(lats, lons, plat, plon)
        # Só atualiza onde é válido e a nova distância é menor
        mask = valid & (dists < min_dists)
        min_dists[mask] = dists[mask]
        min_names[mask] = nome

    return min_dists, min_names


def enriquecer_geo_contexto_vetorizado(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calcula distâncias para todos os POIs de forma vetorizada.
    ~10-50x mais rápido que o apply(axis=1) original para 17k registros.
    """
    logger.info("Calculando Geo-Contexto 360 (VETORIZADO)...")

    lats, lons, valid = _parse_coordenadas(df)
    logger.info(f"  Coordenadas válidas: {valid.sum()}/{len(df)}")

    # ── Distâncias para cada categoria de POI ──

    # Transporte: mescla metrô, trem e BRT
    transporte_todos = {}
    for cat in ('metro_hub', 'trem_supervia', 'brt_stations'):
        transporte_todos.update(POIS_RIO.get(cat, {}))
    dist_transp, nome_transp = _encontrar_mais_proximo_vetorizado(lats, lons, valid, transporte_todos)

    dist_praia, nome_praia = _encontrar_mais_proximo_vetorizado(lats, lons, valid, POIS_RIO.get('praias', {}))
    dist_shop, nome_shop = _encontrar_mais_proximo_vetorizado(lats, lons, valid, POIS_RIO.get('shoppings_premium', {}))
    dist_mercado, nome_mercado = _encontrar_mais_proximo_vetorizado(lats, lons, valid, POIS_RIO.get('mercados_essenciais', {}))
    dist_feira, nome_feira = _encontrar_mais_proximo_vetorizado(lats, lons, valid, POIS_RIO.get('feiras_alimentacao', {}))
    dist_lazer, nome_lazer = _encontrar_mais_proximo_vetorizado(lats, lons, valid, POIS_RIO.get('lazer_verde', {}))
    dist_cultura, nome_cultura = _encontrar_mais_proximo_vetorizado(lats, lons, valid, POIS_RIO.get('cultura_esporte', {}))
    dist_risco, nome_risco = _encontrar_mais_proximo_vetorizado(lats, lons, valid, POIS_RIO.get('areas_sensiveis', {}))
    dist_policia, nome_policia = _encontrar_mais_proximo_vetorizado(lats, lons, valid, POIS_RIO.get('seguranca_publica', {}))
    dist_turismo, nome_turismo = _encontrar_mais_proximo_vetorizado(lats, lons, valid, POIS_RIO.get('pontos_turisticos', {}))
    dist_saude, nome_saude = _encontrar_mais_proximo_vetorizado(lats, lons, valid, POIS_RIO.get('saude_educacao', {}))

    # ── Scores vetorizados ──

    # Score de Mobilidade (0-10)
    score_mob = np.full(len(df), 0.0)
    score_mob[dist_transp < 0.6] = 10.0
    score_mob[(dist_transp >= 0.6) & (dist_transp < 1.5)] = 8.0
    score_mob[(dist_transp >= 1.5) & (dist_transp < 3.0)] = 6.0
    score_mob[(dist_transp >= 3.0) & (dist_transp < 5.0)] = 4.0
    score_mob[dist_transp >= 5.0] = np.maximum(0, 10 - dist_transp[dist_transp >= 5.0] * 2)

    # Score de Segurança (saldo líquido)
    score_seg = np.full(len(df), 5.0)
    score_seg[dist_risco < 0.5] -= 4
    score_seg[(dist_risco >= 0.5) & (dist_risco < 1.0)] -= 2
    score_seg[dist_policia < 0.8] += 2.5
    score_seg[(dist_policia >= 0.8) & (dist_policia < 2.0)] += 1
    score_seg = np.clip(score_seg, 0, 10)

    # Score de Lifestyle (0-10) — acesso a lazer, cultura, praia
    score_life = np.zeros(len(df))
    score_life += np.where(dist_praia < 1.0, 3.0, np.where(dist_praia < 3.0, 1.5, 0.0))
    score_life += np.where(dist_lazer < 1.5, 2.0, np.where(dist_lazer < 3.0, 1.0, 0.0))
    score_life += np.where(dist_cultura < 2.0, 1.5, np.where(dist_cultura < 4.0, 0.5, 0.0))
    score_life += np.where(dist_shop < 2.0, 1.5, np.where(dist_shop < 4.0, 0.5, 0.0))
    score_life += np.where(dist_mercado < 0.5, 1.0, np.where(dist_mercado < 1.5, 0.5, 0.0))
    score_life += np.where(dist_feira < 1.0, 1.0, 0.0)
    score_life = np.clip(score_life, 0, 10)

    # Vocação Airbnb (melhorada — usa bairros turísticos + distância a pontos turísticos)
    bairro_turistico = df['bairro'].str.strip().str.title().isin(BAIRROS_TURISTICOS).values
    vocacao = np.full(len(df), "Baixa", dtype=object)
    
    # Altíssima: bairro turístico + (perto da praia OU perto de transporte OU perto de ponto turístico)
    mask_altissima = bairro_turistico & (
        (dist_praia < 0.8) | (dist_transp < 0.5) | (dist_turismo < 1.0)
    )
    vocacao[mask_altissima] = "Altíssima"
    
    # Alta: bairro turístico + acesso razoável
    mask_alta = ~mask_altissima & bairro_turistico & (
        (dist_praia < 2.0) | (dist_turismo < 2.0)
    )
    vocacao[mask_alta] = "Alta"
    
    # Média: perto de ponto turístico mesmo fora de bairro turístico
    mask_media = ~mask_altissima & ~mask_alta & (dist_turismo < 1.5)
    vocacao[mask_media] = "Média"

    # ── Montagem das colunas ──

    df['dist_praia_km'] = np.round(dist_praia, 2)
    df['praia_prox'] = nome_praia
    df['dist_transporte_km'] = np.round(dist_transp, 2)
    df['transporte_prox'] = nome_transp
    df['dist_shopping_km'] = np.round(dist_shop, 2)
    df['shopping_prox'] = nome_shop
    df['dist_mercado_km'] = np.round(dist_mercado, 2)
    df['mercado_prox'] = nome_mercado
    df['dist_feira_km'] = np.round(dist_feira, 2)
    df['feira_prox'] = nome_feira
    df['dist_lazer_km'] = np.round(dist_lazer, 2)
    df['lazer_prox'] = nome_lazer
    df['dist_cultura_km'] = np.round(dist_cultura, 2)
    df['cultura_prox'] = nome_cultura
    df['dist_risco_km'] = np.round(dist_risco, 2)
    df['risco_prox'] = nome_risco
    df['dist_policia_km'] = np.round(dist_policia, 2)
    df['policia_prox'] = nome_policia
    df['dist_turismo_km'] = np.round(dist_turismo, 2)
    df['turismo_prox'] = nome_turismo
    df['dist_saude_km'] = np.round(dist_saude, 2)
    df['saude_prox'] = nome_saude

    df['score_mobilidade'] = np.round(score_mob, 1)
    df['score_seguranca'] = np.round(score_seg, 1)
    df['score_lifestyle'] = np.round(score_life, 1)
    df['vocacao_airbnb'] = vocacao

    # Invalidar scores onde não há coordenadas
    for col in ['score_mobilidade', 'score_seguranca', 'score_lifestyle']:
        df.loc[~valid, col] = None
    for col in df.columns:
        if col.startswith('dist_') and col.endswith('_km'):
            df.loc[~valid, col] = None

    logger.info("Geo-contexto vetorizado concluído.")
    return df
