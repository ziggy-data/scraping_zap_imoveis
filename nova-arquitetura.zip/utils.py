"""
Funções utilitárias: retry decorator, parsing de texto/números,
geocoding fallback, haversine (escalar e vetorizado).
"""

import re
import time
import math
import logging
import functools
import threading
import urllib.parse
from typing import Tuple

import numpy as np
import requests
from selenium.webdriver.common.by import By

from scraper_rio.config import MONTHS_PT, NOMINATIM_RATE_LIMIT, MAX_RETRY_ATTEMPTS, RETRY_BASE_DELAY

logger = logging.getLogger(__name__)

# Semáforo global para respeitar rate limit do Nominatim
_NOMINATIM_SEMAPHORE = threading.Semaphore(1)

# ══════════════════════════════════════════════════════════════════════════════
#  DECORATOR DE RETRY COM BACKOFF
# ══════════════════════════════════════════════════════════════════════════════

def retry(max_attempts: int = MAX_RETRY_ATTEMPTS, base_delay: float = RETRY_BASE_DELAY,
          exceptions: tuple = (Exception,), logger_instance=None):
    """
    Decorator de retry com backoff linear.
    
    Args:
        max_attempts: Número máximo de tentativas.
        base_delay: Delay base em segundos (multiplica pela tentativa).
        exceptions: Tupla de exceções que disparam retry.
        logger_instance: Logger customizado (usa o do módulo se None).
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            _logger = logger_instance or logger
            last_exception = None
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    last_exception = e
                    if attempt == max_attempts:
                        _logger.error(
                            f"[RETRY] {func.__name__} falhou após {max_attempts} tentativas: {e}"
                        )
                        raise
                    delay = base_delay * attempt
                    _logger.warning(
                        f"[RETRY] {func.__name__} tentativa {attempt}/{max_attempts} falhou: {e}. "
                        f"Aguardando {delay}s..."
                    )
                    time.sleep(delay)
            raise last_exception  # Nunca deve chegar aqui, mas por segurança
        return wrapper
    return decorator


# ══════════════════════════════════════════════════════════════════════════════
#  PARSING DE TEXTO E NÚMEROS
# ══════════════════════════════════════════════════════════════════════════════

def extract_number(text: str, default: int = 0) -> int:
    """Extrai o primeiro número inteiro de uma string."""
    if not text:
        return default
    digits = re.sub(r'[^\d]', '', text)
    return int(digits) if digits else default


def extract_decimal_number(text: str, default: float = 0.0) -> float:
    """Extrai valor monetário no formato R$ X.XXX,XX."""
    if not text:
        return default
    match = re.search(r'R\$\s*([\d\.,]+)', text)
    if match:
        num_str = match.group(1).replace('.', '').replace(',', '.')
        try:
            return float(num_str)
        except ValueError:
            return default
    return default


def safe_get_text(driver, selector: str, default: str = "") -> str:
    """Extrai texto de um elemento CSS de forma segura."""
    try:
        el = driver.find_element(By.CSS_SELECTOR, selector)
        raw = el.get_attribute("textContent") or ""
        return re.sub(r"\s+", " ", raw).strip()
    except Exception:
        return default


def safe_get_attribute(element, selector: str, attribute: str, default: str = "") -> str:
    """Extrai um atributo de um sub-elemento CSS de forma segura."""
    try:
        return element.find_element(By.CSS_SELECTOR, selector).get_attribute(attribute) or default
    except Exception:
        return default


def parse_pt_date_to_iso(pt_date: str) -> str:
    """Converte '12 de março de 2025' para '2025-03-12'."""
    m = re.search(r'(\d{1,2})\s+de\s+([A-Za-zç]+)\s+de\s+(\d{4})', pt_date, re.IGNORECASE)
    if not m:
        return pt_date
    day, month_name, year = m.group(1), m.group(2).lower(), m.group(3)
    month = MONTHS_PT.get(month_name)
    if not month:
        return pt_date
    return f"{int(year):04d}-{month:02d}-{int(day):02d}"


# ══════════════════════════════════════════════════════════════════════════════
#  HAVERSINE — ESCALAR E VETORIZADO
# ══════════════════════════════════════════════════════════════════════════════

def haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Distância em km entre dois pontos (escalar)."""
    R = 6371
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def haversine_vectorized(lat1: np.ndarray, lon1: np.ndarray,
                         lat2: float, lon2: float) -> np.ndarray:
    """
    Distância em km — vetorizado com NumPy.
    lat1/lon1 são arrays (todos os imóveis), lat2/lon2 é um POI.
    """
    R = 6371
    lat1_r, lon1_r = np.radians(lat1), np.radians(lon1)
    lat2_r, lon2_r = np.radians(lat2), np.radians(lon2)
    dlat = lat2_r - lat1_r
    dlon = lon2_r - lon1_r
    a = np.sin(dlat / 2) ** 2 + np.cos(lat1_r) * np.cos(lat2_r) * np.sin(dlon / 2) ** 2
    return R * 2 * np.arcsin(np.sqrt(a))


# ══════════════════════════════════════════════════════════════════════════════
#  GEOCODING FALLBACK (Nominatim / OpenStreetMap)
# ══════════════════════════════════════════════════════════════════════════════

def geocode_fallback_nominatim(endereco: str) -> Tuple[float, float]:
    """
    Geocodifica um endereço via OpenStreetMap Nominatim.
    Respeita rate limit de 1 req/s com semáforo global.
    Retorna (lat, lon) ou (0.0, 0.0) se falhar.
    """
    if not endereco or len(endereco) < 10:
        return 0.0, 0.0

    with _NOMINATIM_SEMAPHORE:
        try:
            clean_address = endereco.split(" - CEP")[0]
            url = (
                f"https://nominatim.openstreetmap.org/search?"
                f"q={urllib.parse.quote(clean_address)}&format=json&limit=1"
            )
            headers = {
                'User-Agent': 'ScraperImoveisRio_StudentProject_v2.0',
                'Referer': 'https://google.com',
            }
            response = requests.get(url, headers=headers, timeout=5)

            if response.status_code == 200:
                data = response.json()
                if data:
                    lat = float(data[0]['lat'])
                    lon = float(data[0]['lon'])
                    logger.debug(f"Geocode OK: {endereco[:50]}... -> ({lat}, {lon})")
                    return lat, lon

        except requests.Timeout:
            logger.debug(f"Geocode timeout: {endereco[:50]}...")
        except Exception as e:
            logger.debug(f"Geocode erro: {e}")
        finally:
            # Rate limit: espera DEPOIS da request, dentro do semáforo
            time.sleep(NOMINATIM_RATE_LIMIT)

    return 0.0, 0.0
