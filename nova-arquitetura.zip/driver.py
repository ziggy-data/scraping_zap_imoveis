"""
Gerenciamento do Chrome driver: criação, configuração stealth,
scroll inteligente e patch de segurança.
"""

import random
import time
import threading
import logging

import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

from scraper_rio.config import USER_AGENTS_LIST

logger = logging.getLogger(__name__)

# Lock global para criação de drivers (evita race condition no Chrome)
_DRIVER_LOCK = threading.Lock()


def _apply_safe_del_patch():
    """Corrige crash no __del__ do Chrome no Windows."""
    def _safe_del(self):
        try:
            self.quit()
        except Exception:
            pass
    uc.Chrome.__del__ = _safe_del


# Aplica o patch ao importar o módulo
_apply_safe_del_patch()


def start_driver(headless: bool = False) -> uc.Chrome:
    """
    Cria uma instância Chrome com proteções anti-detecção.
    
    Args:
        headless: Se True, roda sem janela (economia de RAM).
    """
    with _DRIVER_LOCK:
        options = uc.ChromeOptions()
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-gpu")

        if headless:
            options.add_argument("--headless=new")

        # Turbo mode: bloqueia imagens e notificações
        prefs = {
            "profile.managed_default_content_settings.images": 2,
            "profile.default_content_setting_values.notifications": 2,
        }
        options.add_experimental_option("prefs", prefs)

        # Rotação de User-Agent
        ua = random.choice(USER_AGENTS_LIST)
        options.add_argument(f'--user-agent={ua}')

        driver = uc.Chrome(options=options)
        driver.set_window_size(1100, 800)

    return driver


def scroll_inteligente(driver, scroll_pause: float = 0.4, final_wait: float = 2.0):
    """
    Simula rolagem humana na página.
    
    Args:
        driver: Instância do Chrome.
        scroll_pause: Pausa entre cada scroll (aleatorizada ±30%).
        final_wait: Espera final para render do React.
    """
    try:
        body = driver.find_element(By.TAG_NAME, "body")
        for _ in range(5):
            body.send_keys(Keys.PAGE_DOWN)
            time.sleep(scroll_pause * random.uniform(0.7, 1.3))
        body.send_keys(Keys.PAGE_UP)
        time.sleep(0.5)
        body.send_keys(Keys.END)
        time.sleep(final_wait)
    except Exception as e:
        logger.warning(f"Erro no scroll: {e}")


def safe_restart_driver(driver, headless: bool = False) -> uc.Chrome:
    """
    Reinicia o driver de forma segura (libera memória).
    """
    try:
        driver.quit()
    except Exception:
        pass
    time.sleep(2)
    return start_driver(headless=headless)
