"""
Entry point do Scraper de Imóveis do Rio de Janeiro.

Arquitetura Produtor-Consumidor:
- Produtores: varrem listagens do ZAP Imóveis por zona
- Consumidores: visitam cada imóvel e extraem detalhes
- Pipeline: unifica, enriquece e gera dataset BI-ready

Uso:
    python -m scraper_rio.main
    python -m scraper_rio.main --headless
    python -m scraper_rio.main --pipeline-only  # Só reprocessa CSV existentes
"""

import sys
import glob
import logging
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed

from scraper_rio.config import (
    MAX_LISTING_WORKERS, MAX_DETAILS_WORKERS,
    NUM_PAGINAS, ZONAS_CONFIG,
)
from scraper_rio.scraper import (
    produtor_listagem, consumidor_detalhes,
    LINK_QUEUE, PRODUCERS_DONE, reset_shared_state,
)
from scraper_rio.pipeline import unificar_e_tratar


def setup_logging():
    """Configura logging para arquivo + terminal."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(threadName)-12s] %(levelname)-7s %(message)s",
        datefmt='%H:%M:%S',
        handlers=[
            logging.FileHandler("scraper_execution.log", encoding='utf-8'),
            logging.StreamHandler(),
        ],
    )


def limpar_temps():
    """Remove CSVs temporários de execuções anteriores."""
    import os
    for f in glob.glob("temp_worker_*.csv"):
        try:
            os.remove(f)
        except Exception:
            pass


def build_tarefas_produtor():
    """Monta lista de tarefas para os produtores (dividindo pares/ímpares)."""
    tarefas = []
    for zona in ZONAS_CONFIG:
        if zona['split']:
            tarefas.append({
                "zona": zona,
                "paginas": range(1, NUM_PAGINAS + 1, 2),
                "worker_id": "impar",
            })
            tarefas.append({
                "zona": zona,
                "paginas": range(2, NUM_PAGINAS + 1, 2),
                "worker_id": "par",
            })
        else:
            tarefas.append({
                "zona": zona,
                "paginas": range(1, NUM_PAGINAS + 1),
                "worker_id": "unico",
            })
    return tarefas


def run_scraping(headless: bool = False):
    """Executa o pipeline completo de scraping."""
    logger = logging.getLogger(__name__)

    reset_shared_state()
    limpar_temps()

    tarefas = build_tarefas_produtor()

    logger.info("=" * 60)
    logger.info(f"INICIANDO SCRAPING")
    logger.info(f"  Produtores: {len(tarefas)} tarefas em {MAX_LISTING_WORKERS} workers")
    logger.info(f"  Consumidores: {MAX_DETAILS_WORKERS} workers")
    logger.info(f"  Headless: {headless}")
    logger.info("=" * 60)

    # ── Inicia consumidores PRIMEIRO (ficam esperando a fila) ──
    executor_consumidores = ThreadPoolExecutor(
        max_workers=MAX_DETAILS_WORKERS,
        thread_name_prefix="Consumer",
    )
    futures_consumidores = [
        executor_consumidores.submit(consumidor_detalhes, i, headless)
        for i in range(MAX_DETAILS_WORKERS)
    ]

    # ── Inicia produtores ──
    with ThreadPoolExecutor(
        max_workers=MAX_LISTING_WORKERS,
        thread_name_prefix="Producer",
    ) as executor_produtores:
        futures_produtores = [
            executor_produtores.submit(produtor_listagem, t)
            for t in tarefas
        ]
        # Aguarda todos os produtores terminarem
        for f in as_completed(futures_produtores):
            try:
                f.result()
            except Exception as e:
                logger.error(f"Produtor falhou: {e}")

    # ── Sinaliza que produtores acabaram ──
    logger.info("Produtores finalizaram. Sinalizando consumidores...")
    PRODUCERS_DONE.set()

    # Envia sentinelas para garantir encerramento
    for _ in range(MAX_DETAILS_WORKERS):
        LINK_QUEUE.put(None)

    # ── Aguarda consumidores ──
    for f in as_completed(futures_consumidores):
        try:
            f.result()
        except Exception as e:
            logger.error(f"Consumidor falhou: {e}")

    executor_consumidores.shutdown(wait=True)
    logger.info("Scraping concluído. Iniciando pipeline de tratamento...")


def main():
    parser = argparse.ArgumentParser(description="Scraper de Imóveis RJ")
    parser.add_argument(
        '--headless', action='store_true',
        help='Roda Chrome sem janela (economia de RAM)',
    )
    parser.add_argument(
        '--pipeline-only', action='store_true',
        help='Só executa o pipeline sobre CSVs já existentes (pula scraping)',
    )
    parser.add_argument(
        '--output', type=str, default='DATASET_RIO_BI_READY.csv',
        help='Nome do arquivo de saída',
    )
    args = parser.parse_args()

    setup_logging()
    logger = logging.getLogger(__name__)

    if not args.pipeline_only:
        run_scraping(headless=args.headless)

    # Pipeline de tratamento
    df = unificar_e_tratar(output_filename=args.output)
    if df is not None:
        logger.info(f"Pipeline finalizado com sucesso: {len(df)} imóveis processados.")
    else:
        logger.error("Pipeline falhou. Verifique os logs.")
        sys.exit(1)


if __name__ == "__main__":
    main()
