"""
Mineração de texto via regex:
- Tags de qualidade (arquitetura, vista, estado, conforto)
- Detecção de urgência de venda
- Correção de falsos positivos do script original
"""

import logging

import pandas as pd

logger = logging.getLogger(__name__)


def extrair_tags_avancadas(df: pd.DataFrame) -> pd.DataFrame:
    """
    Extrai tags booleanas da descrição usando regex.
    
    Melhorias sobre a versão anterior:
    - Removido falso positivo: "arborizada" NÃO é sinônimo de "silencioso"
    - Adicionadas tags de terraço, home office, energia solar
    - Grupos de não-captura (?:) em todos os padrões com alternativas
    """
    logger.info("Executando Mineração de Texto (NLP)...")

    desc = df['descricao'].astype(str).str.lower().fillna("")
    if 'titulo' in df.columns:
        titulos = df['titulo'].astype(str).str.lower().fillna("")
        desc = desc + " " + titulos

    # ── ARQUITETURA DE ELITE ──
    df['tag_lamina'] = desc.str.contains(r'\bl[aâ]mina\b', regex=True).astype(int)
    df['tag_planta_circular'] = desc.str.contains(r'planta circular', regex=True).astype(int)
    df['tag_cobertura_linear'] = desc.str.contains(r'cobertura linear', regex=True).astype(int)
    df['tag_pe_direito_alto'] = desc.str.contains(
        r'p[eé] direito (?:alto|duplo)|pé-direito', regex=True
    ).astype(int)
    df['tag_janelao'] = desc.str.contains(r'janel[aã]o|janelas amplas', regex=True).astype(int)

    # ── POSIÇÃO E VISTA ──
    df['tag_indevassavel'] = desc.str.contains(
        r'indevass[aá]vel|vista livre', regex=True
    ).astype(int)
    df['tag_vista_cristo'] = desc.str.contains(
        r'vista.*(?:cristo|redentor|corcovado)', regex=True
    ).astype(int)
    df['tag_vista_pao_acucar'] = desc.str.contains(
        r'vista.*(?:p[aã]o de a[cç][uú]car|enseada)', regex=True
    ).astype(int)
    df['tag_vista_mar'] = desc.str.contains(
        r'vista.*(?:mar|oceano|praia)|frente (?:pro |para o )?mar', regex=True
    ).astype(int)
    df['tag_sol_passante'] = desc.str.contains(r'sol passante', regex=True).astype(int)
    df['tag_sol_manha'] = desc.str.contains(
        r'sol (?:da|pela) manh[ãa]', regex=True
    ).astype(int)

    # ── ESTADO DO IMÓVEL ──
    df['tag_reformado_arquiteto'] = desc.str.contains(
        r'reformado por arquiteto|projeto de ilumina[cç][aã]o|fino acabamento|'
        r'reforma completa|totalmente reformado',
        regex=True
    ).astype(int)
    df['tag_estado_original'] = desc.str.contains(
        r'estado original|precisa de (?:obra|moderniza[cç][aã]o|reforma)|para reformar',
        regex=True
    ).astype(int)
    df['tag_retrofit'] = desc.str.contains(
        r'retrofit|hidr[aá]ulica e el[eé]trica nova', regex=True
    ).astype(int)

    # ── EXCLUSIVIDADE & CONFORTO ──
    df['tag_centro_terreno'] = desc.str.contains(
        r'centro de terreno|afastado da rua', regex=True
    ).astype(int)
    df['tag_exclusivo'] = desc.str.contains(
        r'um por andar|1 por andar|hall privativo|elevador privativo', regex=True
    ).astype(int)
    
    # CORRIGIDO: "arborizada" separado de "silencioso" — são conceitos diferentes
    df['tag_silencioso'] = desc.str.contains(
        r'silencioso|sil[eê]ncio|rua tranquila|rua calma', regex=True
    ).astype(int)
    df['tag_arborizada'] = desc.str.contains(
        r'arborizada|arborizad[ao]|muita [aá]rvore', regex=True
    ).astype(int)

    # ── NOVAS TAGS ──
    df['tag_home_office'] = desc.str.contains(
        r'home office|escrit[oó]rio|coworking|espa[cç]o trabalho', regex=True
    ).astype(int)
    df['tag_terraco'] = desc.str.contains(
        r'terra[cç]o|rooftop|cobertura com [aá]rea', regex=True
    ).astype(int)
    df['tag_energia_solar'] = desc.str.contains(
        r'energia solar|painel solar|fotovoltaic', regex=True
    ).astype(int)
    df['tag_duplex_triplex'] = desc.str.contains(
        r'\bduplex\b|\btriplex\b|\bsobrado\b', regex=True
    ).astype(int)

    # ── LOGÍSTICA & NEGÓCIO ──
    df['tag_vazio'] = desc.str.contains(
        r'vazio|chaves|entrega imediata|desocupado|pronto para morar', regex=True
    ).astype(int)
    df['tag_doc_ok'] = desc.str.contains(
        r'documenta[cç][aã]o (?:ok|cristalina|perfeita)|aceita financiamento|'
        r'aceita fgts',
        regex=True
    ).astype(int)

    logger.info(f"  Tags extraídas: {sum(1 for c in df.columns if c.startswith('tag_'))} tipos")
    return df


def detectar_urgencia_venda(df: pd.DataFrame) -> pd.DataFrame:
    """
    Detecta gatilhos de urgência na descrição e cruza com tempo no mercado.
    """
    logger.info("Procurando gatilhos de urgência...")

    desc = df['descricao'].str.lower().fillna("")

    gatilhos = [
        r"motivo viagem", r"mudan[cç]a", r"invent[aá]rio", r"urgente",
        r"oportunidade [uú]nica", r"abaixo d[ao] avalia[cç][aã]o", r"baixou",
        r"oferta imperd[ií]vel", r"proposta", r"liquidez",
        r"aceita proposta", r"negoci[aá]vel", r"preciso vender",
        r"venda r[aá]pida", r"desapego",
    ]

    regex_urgencia = '|'.join(gatilhos)
    df['gatilho_urgencia'] = desc.str.contains(regex_urgencia, regex=True).astype(int)

    # Oportunidade de Ouro: gatilho + mais de 90 dias no mercado
    dias = pd.to_numeric(df.get('dias_no_mercado', 0), errors='coerce').fillna(0)
    df['alerta_oportunidade_ouro'] = (
        (df['gatilho_urgencia'] == 1) & (dias > 90)
    ).astype(int)

    n_urgentes = df['gatilho_urgencia'].sum()
    n_ouro = df['alerta_oportunidade_ouro'].sum()
    logger.info(f"  {n_urgentes} com urgência, {n_ouro} oportunidades de ouro")

    return df
