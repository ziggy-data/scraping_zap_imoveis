"""
Configurações centralizadas do Scraper de Imóveis do Rio de Janeiro.
Inclui: constantes de performance, zonas, POIs geo-referenciados,
parâmetros financeiros e user-agents para rotação.
"""

from dataclasses import dataclass, field
from typing import Dict, Tuple, List

# ══════════════════════════════════════════════════════════════════════════════
#  PERFORMANCE & THREADING
# ══════════════════════════════════════════════════════════════════════════════

MAX_LISTING_WORKERS = 4    # Produtores (listagem de páginas)
MAX_DETAILS_WORKERS = 8    # Consumidores (detalhes de cada imóvel) — reduzido de 18 para estabilidade
NUM_PAGINAS = 300          # Páginas por zona
RESTART_DRIVER_EVERY = 50  # Reinicia o Chrome a cada N imóveis processados
CONSUMER_QUEUE_TIMEOUT = 5 # Segundos de timeout na fila antes de checar se produtores acabaram

# ══════════════════════════════════════════════════════════════════════════════
#  RETRY & RESILIÊNCIA
# ══════════════════════════════════════════════════════════════════════════════

MAX_RETRY_ATTEMPTS = 3
RETRY_BASE_DELAY = 2       # Segundos (multiplica por tentativa: 2, 4, 6)
NOMINATIM_RATE_LIMIT = 1.1 # Segundos entre requests ao Nominatim

# ══════════════════════════════════════════════════════════════════════════════
#  USER-AGENTS (Rotação Anti-Detecção)
# ══════════════════════════════════════════════════════════════════════════════

USER_AGENTS_LIST = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
]

# ══════════════════════════════════════════════════════════════════════════════
#  ZONAS DE VARREDURA
# ══════════════════════════════════════════════════════════════════════════════

ZONAS_CONFIG = [
    {"nome": "Zona Norte", "slug": "rj+rio-de-janeiro+zona-norte", "split": True},
    {"nome": "Zona Sul",   "slug": "rj+rio-de-janeiro+zona-sul",   "split": True},
    {"nome": "Zona Oeste", "slug": "rj+rio-de-janeiro+zona-oeste", "split": True},
]

# ══════════════════════════════════════════════════════════════════════════════
#  DATAS EM PORTUGUÊS
# ══════════════════════════════════════════════════════════════════════════════

MONTHS_PT = {
    'janeiro': 1, 'fevereiro': 2, 'março': 3, 'abril': 4, 'maio': 5, 'junho': 6,
    'julho': 7, 'agosto': 8, 'setembro': 9, 'outubro': 10, 'novembro': 11, 'dezembro': 12,
}

# ══════════════════════════════════════════════════════════════════════════════
#  PARÂMETROS FINANCEIROS (Parametrizados — ajuste conforme mercado)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class ParametrosFinanceiros:
    """Parâmetros de financiamento e custos de aquisição."""
    taxa_itbi: float = 0.03
    taxa_cartorio: float = 0.015
    
    # Juros diferenciados por faixa
    juros_aa_mercado: float = 0.105   # ~10.5% a.a. — usados/mercado livre
    juros_aa_mcmv_f3: float = 0.075   # ~7.5% a.a. — MCMV Faixa 3
    juros_aa_mcmv_f2: float = 0.045   # ~4.5% a.a. — MCMV Faixa 2
    teto_mcmv: float = 350_000.0      # Teto de valor para MCMV
    
    percentual_financiavel: float = 0.80
    prazo_meses: int = 420            # 35 anos
    yield_aluguel: float = 0.0045     # 0.45% do valor como aluguel mensal estimado
    
    def juros_para(self, valor: float) -> float:
        """Retorna taxa anual adequada ao perfil do imóvel."""
        if valor <= self.teto_mcmv:
            return self.juros_aa_mcmv_f3
        return self.juros_aa_mercado
    
    def juros_mensais(self, valor: float) -> float:
        """Retorna taxa mensal equivalente."""
        return (1 + self.juros_para(valor)) ** (1/12) - 1


PARAMS_FINANCEIROS = ParametrosFinanceiros()

# ══════════════════════════════════════════════════════════════════════════════
#  MAPEAMENTO DE FEATURES DO SELENIUM (Seletores CSS)
# ══════════════════════════════════════════════════════════════════════════════

MAP_IMOVEL = {
    'aceita_pet': "li[itemprop='PETS_ALLOWED']",
    'tem_vista_pro_mar': "li[itemprop='SEA_VIEW']",
    'tem_janela_grande': "li[itemprop='LARGE_WINDOW']",
    'tem_ar_condicionado': "li[itemprop='AIR_CONDITIONING']",
    'tem_banheira': "li[itemprop='BATHTUB']",
    'tem_banheiro_servico': "li[itemprop='SERVICE_BATHROOM']",
    'tem_armario_cozinha': "li[itemprop='KITCHEN_CABINETS']",
    'tem_armario_banheiro': "li[itemprop='BATHROOM_CABINETS']",
    'tem_piso_madeira': "li[itemprop='WOOD_FLOOR']",
    'tem_box_blindex': "li[itemprop='BLINDEX_BOX']",
    'tem_area_servico': "li[itemprop='SERVICE_AREA']",
    'tem_closet': "li[itemprop='CLOSET']",
    'tem_copa': "li[itemprop='COPA']",
    'tem_varanda': "li[itemprop='BALCONY']",
    'tem_varanda_gourmet': "li[itemprop='GOURMET_BALCONY']",
}

MAP_CONDOMINIO = {
    'tem_portaria_24h': "li[itemprop='CONCIERGE_24H']",
    'tem_armario_embutido': "li[itemprop='BUILTIN_WARDROBE']",
    'tem_estacionamento': "li[itemprop='PARKING']",
    'tem_academia': "li[itemprop='GYM']",
    'tem_salao_festas': "li[itemprop='PARTY_HALL']",
    'tem_piscina': "li[itemprop='POOL']",
    'tem_interfone': "li[itemprop='INTERCOM']",
    'tem_sala_massagem': "li[itemprop='MASSAGE_ROOM']",
    'tem_churrasqueira': "li[itemprop='BARBECUE_GRILL']",
    'tem_quadra_poliesportiva': "li[itemprop='SPORTS_COURT']",
    'tem_sauna': "li[itemprop='SAUNA']",
    'tem_playground': "li[itemprop='PLAYGROUND']",
    'tem_squash': "li[itemprop='SQUASH']",
    'tem_condominio_fechado': "li[itemprop='GATED_COMMUNITY']",
    'tem_elevador': "li[itemprop='ELEVATOR']",
    'tem_loja': "li[itemprop='STORES']",
    'tem_administracao': "li[itemprop='ADMINISTRATION']",
    'tem_zelador': "li[itemprop='CARETAKER']",
}

# Lista de colunas do CSV dos workers (ordem definida uma vez)
CSV_FIELDNAMES = [
    # Identificação e Valores
    'url', 'valor_R$', 'area_m2', 'quartos', 'vagas', 'banheiros', 'suites', 'andar',
    'tipo', 'bairro', 'cidade', 'rua', 'numero', 'endereco_completo',
    'condominio_R$', 'iptu_R$',
    # Detalhes do Anúncio
    'destaque', 'imagem_url', 'descricao', 'corretora',
    'nota_media', 'total_avaliacoes', 'anuncio_criado',
    'latitude', 'longitude', 'coordenadas', 'origem_geo',
    # Atributos do Imóvel
    *MAP_IMOVEL.keys(),
    # Atributos do Condomínio
    *MAP_CONDOMINIO.keys(),
]

# ══════════════════════════════════════════════════════════════════════════════
#  PONTOS DE INTERESSE (POIs) — MAPEAMENTO ESTRATÉGICO DO RIO
# ══════════════════════════════════════════════════════════════════════════════

POIS_RIO: Dict[str, Dict[str, Tuple[float, float]]] = {
    "praias": {
        "Leme": (-22.9635, -43.1717),
        "Copacabana (Copacabana Palace)": (-22.9703, -43.1820),
        "Copacabana (Posto 5)": (-22.9778, -43.1903),
        "Ipanema (Posto 9)": (-22.9866, -43.2046),
        "Leblon (Posto 12)": (-22.9873, -43.2215),
        "São Conrado (Pepino)": (-22.9975, -43.2647),
        "Barra (Jardim Oceânico)": (-23.0125, -43.3087),
        "Barra (Posto 4)": (-23.0116, -43.3245),
        "Reserva/Recreio": (-23.0182, -43.4332),
        "Flamengo (Aterro)": (-22.9324, -43.1730),
        "Botafogo (Enseada)": (-22.9463, -43.1819),
    },
    "lazer_verde": {
        "Lagoa Rodrigo de Freitas": (-22.9734, -43.2114),
        "Aterro do Flamengo": (-22.9221, -43.1733),
        "Jardim Botânico": (-22.9676, -43.2233),
        "Parque Lage": (-22.9602, -43.2119),
        "Quinta da Boa Vista": (-22.9056, -43.2244),
        "Parque Madureira": (-22.8732, -43.3402),
        "Parque Piedade (Antiga Gama Filho)": (-22.8929, -43.3080),
        "Parque Rita Lee (Barra Olímpica)": (-22.9770, -43.3940),
        "Parque Realengo (Susana Naspolini)": (-22.8760, -43.4300),
    },
    "shoppings_premium": {
        "Shopping Leblon/Design": (-22.9824, -43.2173),
        "RioSul": (-22.9567, -43.1769),
        "BarraShopping": (-22.9995, -43.3556),
        "Village Mall": (-23.0003, -43.3533),
        "Shopping Tijuca": (-22.9234, -43.2360),
        "NorteShopping": (-22.8879, -43.2831),
        "Nova América": (-22.8794, -43.2721),
        "Botafogo Praia": (-22.9510, -43.1840),
    },
    "metro_hub": {
        "Metro Cardeal Arcoverde": (-22.9644, -43.1812),
        "Metro General Osório": (-22.9846, -43.1977),
        "Metro Nossa Sra Paz": (-22.9839, -43.2065),
        "Metro Jardim de Alah": (-22.9829, -43.2154),
        "Metro Antero de Quental": (-22.9849, -43.2232),
        "Metro Botafogo": (-22.9510, -43.1840),
        "Metro Flamengo": (-22.9324, -43.1790),
        "Metro Largo do Machado": (-22.9298, -43.1780),
        "Metro Catete": (-22.9260, -43.1770),
        "Metro Carioca": (-22.9079, -43.1772),
        "Metro Saens Peña": (-22.9244, -43.2325),
        "Metro Uruguai": (-22.9317, -43.2405),
        "Metro São Francisco Xavier": (-22.9208, -43.2241),
        "Metro Jd Oceânico": (-23.0076, -43.3106),
        "Metro São Conrado": (-22.9912, -43.2543),
        "Metro Pavuna": (-22.8126, -43.3600),
        "Metro São Cristóvão": (-22.9097, -43.2223),
    },
    "trem_supervia": {
        "Estação Central do Brasil": (-22.9042, -43.1887),
        "Estação São Cristóvão": (-22.9097, -43.2223),
        "Estação Méier": (-22.9018, -43.2781),
        "Estação Madureira": (-22.8769, -43.3374),
        "Estação Deodoro": (-22.8549, -43.3837),
        "Estação Bangu": (-22.8754, -43.4658),
        "Estação Campo Grande": (-22.9022, -43.5604),
    },
    "brt_stations": {
        "Term. Alvorada": (-22.9992, -43.3663),
        "Term. Jardim Oceânico": (-23.0076, -43.3106),
        "Estação Vicente de Carvalho": (-22.8546, -43.3134),
        "Term. Recreio": (-23.0139, -43.4533),
        "Estação Taquara": (-22.9213, -43.3725),
        "Term. Paulo da Portela": (-22.8765, -43.3385),
        "Estação Galeão (Aeroporto)": (-22.8079, -43.2530),
    },
    "saude_educacao": {
        "Colégio Pedro II (Humaitá)": (-22.9569, -43.1936),
        "Colégio Pedro II (Tijuca)": (-22.9189, -43.2183),
        "Colégio Pedro II (Centro)": (-22.9067, -43.2044),
        "Colégio Pedro II (São Cristóvão)": (-22.8997, -43.2217),
        "Colégio Pedro II (Realengo)": (-22.8789, -43.4300),
        "CAp UFRJ (Lagoa)": (-22.9714, -43.2033),
        "Colégio Militar (Tijuca)": (-22.9158, -43.2269),
        "Santo Inácio": (-22.9535, -43.1912),
        "São Bento": (-22.8983, -43.1772),
        "Hosp. Copa D'Or": (-22.9695, -43.1878),
        "Hosp. Barra D'Or": (-22.9942, -43.3637),
        "Hosp. Souza Aguiar (Emergência)": (-22.9077, -43.1908),
        "Hosp. Miguel Couto (Gávea)": (-22.9803, -43.2250),
        "Hosp. Lourenço Jorge (Barra)": (-22.9992, -43.3663),
        "INCA (Centro)": (-22.9103, -43.1856),
    },
    "areas_sensiveis": {
        # Zona Sul
        "Rocinha (Baixo/Autoestrada)": (-22.9934, -43.2547),
        "Vidigal (Entrada)": (-22.9943, -43.2348),
        "Cantagalo/Pavão (Copacabana)": (-22.9763, -43.1952),
        "Santa Marta (Botafogo)": (-22.9482, -43.1903),
        "Tabajaras (Copacabana/Botafogo)": (-22.9619, -43.1936),
        "Babilônia/Chapéu (Leme)": (-22.9608, -43.1678),
        # Tijuca / Grande Méier
        "Complexo do Lins": (-22.9189, -43.2798),
        "Morro dos Macacos (Vila Isabel)": (-22.9187, -43.2530),
        "Salgueiro/Borel (Tijuca)": (-22.9376, -43.2435),
        "Turano (Rio Comprido)": (-22.9268, -43.2133),
        "Mangueira": (-22.9038, -43.2393),
        "Jacarezinho": (-22.8877, -43.2533),
        # Leopoldina / Zona Norte Profunda
        "Complexo do Alemão": (-22.8587, -43.2725),
        "Complexo da Maré": (-22.8617, -43.2422),
        "Complexo da Penha": (-22.8468, -43.2829),
        "Serrinha (Madureira)": (-22.8681, -43.3323),
        "Juramento": (-22.8633, -43.3130),
        "Chapadão": (-22.8336, -43.3592),
        "Pedreira": (-22.8258, -43.3670),
        # Zona Oeste
        "Cidade de Deus (CDD)": (-22.9489, -43.3622),
        "Rio das Pedras": (-22.9737, -43.3283),
        "Vila Kennedy": (-22.8608, -43.4862),
        "Gardênia Azul": (-22.9599, -43.3486),
    },
    "seguranca_publica": {
        "2º BPM (Botafogo)": (-22.9525, -43.1868),
        "19º BPM (Copacabana)": (-22.9688, -43.1925),
        "23º BPM (Leblon)": (-22.9863, -43.2210),
        "6º BPM (Tijuca)": (-22.9272, -43.2355),
        "3º BPM (Méier)": (-22.9022, -43.2801),
        "16º BPM (Olaria)": (-22.8465, -43.2625),
        "41º BPM (Irajá)": (-22.8358, -43.3370),
        "9º BPM (Rocha Miranda)": (-22.8569, -43.3422),
        "31º BPM (Barra/Recreio)": (-23.0033, -43.3600),
        "18º BPM (Jacarepaguá)": (-22.9300, -43.3522),
        "Cidade da Polícia (Jacaré)": (-22.8923, -43.2519),
        "12ª DP (Copacabana)": (-22.9678, -43.1843),
        "14ª DP (Leblon)": (-22.9839, -43.2227),
        "19ª DP (Tijuca)": (-22.9242, -43.2320),
        "16ª DP (Barra)": (-23.0089, -43.3130),
    },
    "mercados_essenciais": {
        # Zona Sul
        "Mundial (Botafogo)": (-22.9497, -43.1865),
        "Mundial (Copacabana/Siqueira)": (-22.9680, -43.1870),
        "Zona Sul (Ipanema/Gen. Osório)": (-22.9842, -43.1983),
        "Zona Sul (Leblon/Bartolomeu)": (-22.9860, -43.2250),
        "Pão de Açúcar (Copacabana)": (-22.9682, -43.1855),
        "Pão de Açúcar (Flamengo)": (-22.9360, -43.1765),
        "Mundial (Largo do Machado)": (-22.9305, -43.1785),
        "Princesa (Leme)": (-22.9630, -43.1680),
        "Zona Sul (São Conrado)": (-22.9970, -43.2630),
        "Pão de Açúcar (Botafogo/Voluntários)": (-22.9530, -43.1900),
        # Grande Tijuca
        "Guanabara (Tijuca/Maxwell)": (-22.9238, -43.2458),
        "Mundial (Tijuca/Santo Afonso)": (-22.9254, -43.2343),
        "Extra/Assaí (Mariz e Barros)": (-22.9150, -43.2180),
        "Guanabara (Vila Isabel)": (-22.9152, -43.2483),
        "Campeão (Praça da Bandeira)": (-22.9120, -43.2150),
        "Prezunic (Tijuca/Fonseca Telles)": (-22.9050, -43.2250),
        "Mundial (Grajaú)": (-22.9200, -43.2600),
        # Zona Norte: Méier / Suburbana
        "Guanabara (Campinho)": (-22.8833, -43.3467),
        "Prezunic (Campinho/Jaurú)": (-22.8850, -43.3500),
        "Prezunic (Méier)": (-22.8988, -43.2758),
        "Assaí (Méier/Dias da Cruz)": (-22.9050, -43.2800),
        "Guanabara (Engenho de Dentro)": (-22.8950, -43.2950),
        "Guanabara (Piedade)": (-22.8902, -43.3031),
        "Inter (Cascadura)": (-22.8800, -43.3250),
        "Mundial (Cachambi)": (-22.8880, -43.2750),
        "Prezunic (Benfica)": (-22.8900, -43.2400),
        # Leopoldina / Ilha
        "Mundial (Ramos)": (-22.8553, -43.2621),
        "Guanabara (Penha)": (-22.8400, -43.2800),
        "Guanabara (Bonsucesso)": (-22.8600, -43.2500),
        "Mundial (Ilha/Cacuia)": (-22.8050, -43.1950),
        "Assaí (Ilha/Galeão)": (-22.8100, -43.2300),
        "Mundial (Vaz Lobo)": (-22.8550, -43.3200),
        "Guanabara (Irajá)": (-22.8350, -43.3300),
        "Prezunic (Vista Alegre)": (-22.8300, -43.3100),
        # Jacarepaguá
        "Mundial (Freguesia)": (-22.9350, -43.3400),
        "Prezunic (Freguesia)": (-22.9450, -43.3450),
        "Assaí (Tanque)": (-22.9248, -43.3592),
        "Guanabara (Tanque)": (-22.9200, -43.3600),
        "Prezunic (Taquara)": (-22.9213, -43.3725),
        "Guanabara (Taquara)": (-22.9150, -43.3800),
        "Prezunic (Pechincha)": (-22.9300, -43.3550),
        # Barra / Recreio
        "Guanabara (Barra)": (-23.0062, -43.3389),
        "Mundial (Jd Oceânico)": (-23.0128, -43.3052),
        "Zona Sul (Barra/Alfa)": (-23.0000, -43.3500),
        "Carrefour (Barra)": (-22.9980, -43.3600),
        "Prezunic (Recreio)": (-23.0075, -43.4431),
        "Mundial (Recreio)": (-23.0180, -43.4600),
        "Zona Sul (Recreio)": (-23.0150, -43.4500),
        # Zona Oeste Profunda
        "Guanabara (Realengo)": (-22.8750, -43.4300),
        "Inter (Bangu)": (-22.8754, -43.4658),
        "Guanabara (Bangu)": (-22.8800, -43.4600),
        "Guanabara (Campo Grande)": (-22.9022, -43.5604),
        "Prezunic (Campo Grande)": (-22.9100, -43.5500),
        "Assaí (Santa Cruz)": (-22.9200, -43.6800),
    },
    "feiras_alimentacao": {
        # Zona Sul & Centro
        "Feira Ipanema (Pça N. Sra Paz - Orgânica)": (-22.9839, -43.2065),
        "Feira Leblon (Pça Antero de Quental - Orgânica)": (-22.9849, -43.2232),
        "Feira Botafogo (Pça Nelson Mandela)": (-22.9510, -43.1840),
        "Feira Flamengo (Pça José de Alencar)": (-22.9298, -43.1780),
        "Feira Copacabana (Domingo/Serzedelo)": (-22.9680, -43.1870),
        "Feira Humaitá (Quarta)": (-22.9560, -43.1930),
        "Feira Laranjeiras (General Glicério)": (-22.9344, -43.1878),
        "Feira Glória (Domingo/Augusto Severo)": (-22.9180, -43.1760),
        "Feira Catete (Sábado/Bento Lisboa)": (-22.9280, -43.1780),
        # Grande Tijuca
        "Feira Tijuca (Sexta/S. Fco Xavier)": (-22.9208, -43.2241),
        "Feira Tijuca (Domingo/Haddock Lobo)": (-22.9150, -43.2180),
        "Feira Orgânica Tijuca (Pça Xavier de Brito)": (-22.9246, -43.2433),
        "Feira Grajaú (Domingo/Verdun)": (-22.9260, -43.2620),
        "Feira Vila Isabel (Terça/Boulevard)": (-22.9170, -43.2450),
        "Feira Andaraí (Sábado/Barão de Mesquita)": (-22.9320, -43.2500),
        # Zona Norte: Méier / Suburbana
        "Feira Méier (Domingo/Dias da Cruz)": (-22.9020, -43.2800),
        "Feira Engenho de Dentro (Quinta)": (-22.8960, -43.2960),
        "Feira Cachambi (Domingo/Honório)": (-22.8880, -43.2750),
        "Feira Piedade (Sábado/Guanabara)": (-22.8900, -43.3030),
        "Feira Pilares (Domingo/João Ribeiro)": (-22.8820, -43.2950),
        "Feira Engenho Novo (Terça/Barão)": (-22.9080, -43.2650),
        "Feira Abolição (Domingo/Largo)": (-22.8850, -43.2990),
        "Feira Encantado (Quarta/Clarimundo)": (-22.8940, -43.3000),
        # Leopoldina / Ilha
        "Feira Olaria (Quarta/Cinco Bocas)": (-22.8460, -43.2630),
        "Feira Ramos (Sábado/Euclides Faria)": (-22.8520, -43.2600),
        "Feira Bonsucesso (Terça)": (-22.8600, -43.2500),
        "Feira Penha (Domingo/IAPI)": (-22.8400, -43.2800),
        "Feira Vila da Penha (Domingo)": (-22.8450, -43.3150),
        "Feira Vista Alegre (Sábado)": (-22.8300, -43.3100),
        "Feira Ilha (Domingo/Cacuia)": (-22.8050, -43.1950),
        "Feira Ilha (Sábado/Jd Guanabara)": (-22.8100, -43.2050),
        # Madureira / Irajá
        "Feira Madureira (Sábado/Viaduto)": (-22.8730, -43.3400),
        "Feira Irajá (Quarta/Metrô)": (-22.8350, -43.3300),
        "Feira Vicente de Carvalho (Sexta)": (-22.8540, -43.3130),
        "Feira Pavuna (Domingo/Metrô)": (-22.8120, -43.3600),
        "Feira Rocha Miranda (Sábado/Praça)": (-22.8560, -43.3420),
        # Jacarepaguá / Barra / Recreio
        "Feira Freguesia (Sábado/Pça Camisão)": (-22.9370, -43.3400),
        "Feira Pechincha (Quinta/Geremário)": (-22.9300, -43.3550),
        "Feira Taquara (Domingo)": (-22.9210, -43.3720),
        "Feira Vila Valqueire (Sábado)": (-22.8880, -43.3650),
        "Feira Praça Seca (Domingo)": (-22.8883, -43.3550),
        "Feira Orgânica Barra (Pça do Ó)": (-23.0113, -43.3193),
        "Feira Recreio (Domingo)": (-23.0180, -43.4600),
        # Zona Oeste
        "Feira Bangu (Domingo)": (-22.8750, -43.4650),
        "Feira Realengo (Sábado)": (-22.8760, -43.4300),
        "Feira Campo Grande (Domingo)": (-22.9020, -43.5600),
        "Feira Santa Cruz (Domingo)": (-22.9200, -43.6800),
    },
    "cultura_esporte": {
        "Vila Olímpica do Encantado": (-22.8950, -43.2950),
        "Parque Radical de Deodoro": (-22.8549, -43.3837),
        "Vila Olímpica da Maré": (-22.8617, -43.2422),
        "Aterro do Flamengo (Esportes)": (-22.9221, -43.1733),
        "Ciclovia da Lagoa": (-22.9734, -43.2114),
        "Cidade das Artes (Barra)": (-22.9992, -43.3663),
        "Teatro Municipal / Cinelândia": (-22.9090, -43.1770),
        "Imperator (Méier)": (-22.8988, -43.2758),
        "Sesc Tijuca": (-22.9230, -43.2350),
        "Espaço Cultural Madureira": (-22.8732, -43.3402),
        "CCBB (Centro)": (-22.9015, -43.1765),
    },
    "pontos_turisticos": {
        "Cristo Redentor": (-22.9519, -43.2105),
        "Pão de Açúcar": (-22.9489, -43.1569),
        "Arcos da Lapa": (-22.9134, -43.1793),
        "Escadaria Selarón": (-22.9156, -43.1790),
        "Maracanã": (-22.9121, -43.2302),
        "AquaRio": (-22.8936, -43.1884),
        "Museu do Amanhã": (-22.8940, -43.1814),
        "Santa Teresa (Largo dos Guimarães)": (-22.9219, -43.1851),
    },
}

# Bairros com vocação turística conhecida (para score Airbnb melhorado)
BAIRROS_TURISTICOS = {
    'Copacabana', 'Ipanema', 'Leblon', 'Botafogo', 'Flamengo',
    'Leme', 'Catete', 'Glória', 'Santa Teresa', 'Lapa',
    'Centro', 'Barra Da Tijuca', 'São Conrado', 'Gávea',
    'Humaitá', 'Lagoa', 'Jardim Botânico', 'Urca',
}
