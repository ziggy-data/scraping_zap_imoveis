"""
Qualidade dos dados: limpeza, deduplicação, médias inteligentes,
segmentação de mercado, tempo no mercado, saturação e índice de conforto.
"""

import re
import logging

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
#  LIMPEZA E DEDUPLICAÇÃO
# ══════════════════════════════════════════════════════════════════════════════

def aplicar_regras_qualidade(df: pd.DataFrame) -> pd.DataFrame:
    """Limpa, deduplica e aplica filtros de sanidade."""
    logger.info(f"Iniciando tratamento de qualidade. Dados brutos: {len(df)}")

    # ID único a partir da URL
    df['id_imovel'] = df['url'].apply(
        lambda x: m.group(1) if (m := re.search(r'id-(\d+)', str(x))) else str(x)
    )
    before = len(df)
    df.drop_duplicates(subset=['id_imovel'], keep='first', inplace=True)
    logger.info(f"  Duplicatas removidas: {before - len(df)}")

    # Conversão numérica
    cols_num = ['valor_R$', 'area_m2', 'condominio_R$', 'iptu_R$', 'quartos', 'vagas', 'banheiros', 'suites']
    for col in cols_num:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)

    # Filtro de sanidade
    mask = (df['valor_R$'] > 10000) & (df['area_m2'] >= 10)
    df_clean = df[mask].copy()
    logger.info(f"  Removidos por sanidade: {len(df) - len(df_clean)}")

    # Feature: preço por m²
    df_clean['preco_m2'] = (df_clean['valor_R$'] / df_clean['area_m2']).round(2)

    # Remoção de outliers extremos (1% inferior e superior)
    if len(df_clean) > 20:
        q_low = df_clean['preco_m2'].quantile(0.01)
        q_hi = df_clean['preco_m2'].quantile(0.99)
        before = len(df_clean)
        df_clean = df_clean[(df_clean['preco_m2'] > q_low) & (df_clean['preco_m2'] < q_hi)].copy()
        logger.info(f"  Outliers removidos: {before - len(df_clean)}")

    # Padronização de texto
    for col in ['bairro', 'tipo', 'cidade', 'descricao', 'rua', 'corretora']:
        if col in df_clean.columns:
            df_clean[col] = df_clean[col].astype(str).str.strip().str.title()

    # Flag de vaga (para índice de conforto)
    df_clean['bool_vaga'] = (pd.to_numeric(df_clean['vagas'], errors='coerce').fillna(0) > 0).astype(int)

    logger.info(f"Dados qualificados: {len(df_clean)} registros finais.")
    return df_clean


# ══════════════════════════════════════════════════════════════════════════════
#  MÉDIAS INTELIGENTES (Rua > Bairro)
# ══════════════════════════════════════════════════════════════════════════════

def calcular_media_inteligente(df: pd.DataFrame, min_amostras_rua: int = 3) -> pd.DataFrame:
    """Calcula preço/m² de referência com hierarquia rua > bairro."""
    logger.info("Calculando médias inteligentes (Hierarquia Rua > Bairro)...")

    df['preco_m2_real'] = np.where(
        df['area_m2'] > 0,
        df['valor_R$'] / df['area_m2'],
        0.0
    )

    df_calc = df[df['preco_m2_real'] > 100].copy()

    # Médias por bairro
    stats_bairro = (
        df_calc.groupby('bairro')['preco_m2_real']
        .mean().reset_index()
        .rename(columns={'preco_m2_real': 'media_bairro_m2'})
    )

    # Médias por rua (com contagem)
    stats_rua = (
        df_calc.groupby(['bairro', 'rua'])['preco_m2_real']
        .agg(['mean', 'count']).reset_index()
        .rename(columns={'mean': 'media_rua_m2', 'count': 'qtd_amostras_rua'})
    )

    df = pd.merge(df, stats_bairro, on='bairro', how='left')
    df = pd.merge(df, stats_rua, on=['bairro', 'rua'], how='left')

    # Escolha de referência: rua (se amostras suficientes) ou bairro
    rua_valida = (
        df['rua'].notna() &
        ~df['rua'].isin(["Rua Não Informada", "Endereço Não Disponível", "Nan"]) &
        (df['qtd_amostras_rua'] >= min_amostras_rua)
    )
    df['preco_m2_referencia'] = np.where(rua_valida, df['media_rua_m2'], df['media_bairro_m2'])
    df['origem_referencia'] = np.where(rua_valida, "Rua", "Bairro (Amostra insuficiente na rua)")
    df['preco_m2_referencia'] = df['preco_m2_referencia'].round(2)

    # Diferença percentual
    with np.errstate(divide='ignore', invalid='ignore'):
        df['diferenca_percentual'] = np.where(
            df['preco_m2_referencia'] > 0,
            ((df['preco_m2_real'] - df['preco_m2_referencia']) / df['preco_m2_referencia'] * 100).round(1),
            0.0
        )

    return df


# ══════════════════════════════════════════════════════════════════════════════
#  SATURAÇÃO DE RUA
# ══════════════════════════════════════════════════════════════════════════════

def analisar_saturacao_rua(df: pd.DataFrame) -> pd.DataFrame:
    """Identifica ruas com concentração anormal de ofertas (risco de fuga)."""
    logger.info("Analisando concentração de ofertas (Risco de Fuga)...")

    oferta_rua = (
        df.groupby(['bairro', 'rua'])['url']
        .count().reset_index()
        .rename(columns={'url': 'qtd_na_rua'})
    )
    media_bairro = (
        oferta_rua.groupby('bairro')['qtd_na_rua']
        .mean().reset_index()
        .rename(columns={'qtd_na_rua': 'media_ofertas_por_rua_no_bairro'})
    )

    df = pd.merge(df, oferta_rua, on=['bairro', 'rua'], how='left')
    df = pd.merge(df, media_bairro, on='bairro', how='left')

    def classificar_risco(row):
        qtd = row.get('qtd_na_rua', 0)
        media = row.get('media_ofertas_por_rua_no_bairro', 1)
        if pd.isna(qtd) or qtd < 3:
            return "Normal"
        if qtd > (media * 3):
            return "ALERTA: Fuga Possível (Oferta Muito Alta)"
        elif qtd > (media * 1.5):
            return "Oferta Elevada"
        return "Normal/Baixa"

    df['alerta_oferta_rua'] = df.apply(classificar_risco, axis=1)
    return df


# ══════════════════════════════════════════════════════════════════════════════
#  SEGMENTAÇÃO DINÂMICA
# ══════════════════════════════════════════════════════════════════════════════

def segmentar_mercado_dinamico(df: pd.DataFrame) -> pd.DataFrame:
    """Segmenta imóveis por faixa de preço e tamanho via quintis."""
    logger.info("Segmentando mercado via Estatística (Quantiles)...")

    labels_preco = ['Econômico (Top 20% Baratos)', 'Médio-Baixo', 'Médio-Alto', 'Alto Padrão', 'Luxo (Top 20% Caros)']
    try:
        df['segmento_mercado'] = pd.qcut(df['valor_R$'], q=5, labels=labels_preco, duplicates='drop')
    except ValueError:
        df['segmento_mercado'] = "Padrão"

    labels_area = ['Compacto', 'Padrão', 'Confortável', 'Espaçoso', 'Gigante']
    try:
        df['perfil_tamanho'] = pd.qcut(df['area_m2'], q=5, labels=labels_area, duplicates='drop')
    except ValueError:
        df['perfil_tamanho'] = "Padrão"

    return df


# ══════════════════════════════════════════════════════════════════════════════
#  DIAS NO MERCADO
# ══════════════════════════════════════════════════════════════════════════════

def calcular_dias_mercado(df: pd.DataFrame) -> pd.DataFrame:
    """Calcula quantos dias o anúncio está ativo e classifica."""
    logger.info("Calculando Dias no Mercado (DOM)...")

    df['dt_anuncio'] = pd.to_datetime(df['anuncio_criado'], errors='coerce')
    hoje = pd.Timestamp.now().normalize()
    df['dias_no_mercado'] = (hoje - df['dt_anuncio']).dt.days.fillna(0).astype(int)

    bins = [0, 7, 30, 90, 180, 999999]
    labels = [
        "Recém Chegado (Hype)",
        "Recente (1 Mês)",
        "Normal (3 Meses)",
        "Encalhado (6 Meses)",
        "Zombie (> 6 Meses - Barganha Extrema)",
    ]
    df['status_temporal'] = pd.cut(df['dias_no_mercado'], bins=bins, labels=labels, right=True)

    return df


# ══════════════════════════════════════════════════════════════════════════════
#  ÍNDICE DE CONFORTO 2.0
# ══════════════════════════════════════════════════════════════════════════════

def calcular_indice_conforto(df: pd.DataFrame) -> pd.DataFrame:
    """
    Score de conforto (0-100) baseado em infraestrutura, lazer,
    bem-estar (NLP) e bônus geográfico.
    """
    logger.info("Calculando Índice de Conforto 2.0...")

    # Pesos: infraestrutura
    w_infra = {
        'bool_vaga': 15, 'tem_portaria_24h': 10, 'tem_elevador': 10,
        'tem_varanda': 8, 'tem_ar_condicionado': 5, 'tem_armario_embutido': 2,
        'tem_box_blindex': 1,
    }
    # Pesos: lazer
    w_lazer = {
        'tem_piscina': 5, 'tem_academia': 4, 'tem_churrasqueira': 3,
        'tem_salao_festas': 2, 'tem_sauna': 2, 'tem_varanda_gourmet': 5,
    }
    # Pesos: bem-estar (tags NLP)
    w_bem_estar = {
        'tag_sol_manha': 8, 'tag_silencioso': 6, 'tag_indevassavel': 5,
        'tag_vista_mar': 5, 'tag_reformado_arquiteto': 5, 'tag_vazio': 2,
        'tag_home_office': 3, 'tag_arborizada': 3,
    }

    score = np.zeros(len(df))

    for pesos in (w_infra, w_lazer, w_bem_estar):
        for col, peso in pesos.items():
            if col in df.columns:
                score += pd.to_numeric(df[col], errors='coerce').fillna(0).values * peso

    # Bônus geográfico
    if 'dist_transporte_km' in df.columns:
        dist_t = pd.to_numeric(df['dist_transporte_km'], errors='coerce').fillna(99).values
        score += (dist_t < 0.7).astype(int) * 10

    if 'dist_mercado_km' in df.columns:
        dist_m = pd.to_numeric(df['dist_mercado_km'], errors='coerce').fillna(99).values
        score += (dist_m < 0.4).astype(int) * 5

    df['score_conforto'] = np.clip(score, 0, 100).astype(int)

    return df
